document.getElementById('startSlideshow').addEventListener('click', function () 
{
    document.getElementById('slideshowContainer').style.display = 'block';
    startSlideshow();
});

function startSlideshow() 
{
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;

    function showSlide(index) 
	{
        slides.forEach((slide, i) => 
		{
            slide.style.display = i === index ? 'block' : 'none';
        });
    }

    function nextSlide() 
	{
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    const interval = 3000; 

    setInterval(nextSlide, interval);
    showSlide(currentSlide);
}